package atv2;

public class Reserva {
    public Hospede hospede;
    public String dataCheckIn;  
    public String dataCheckOut; 
    public int numeroQuartosReservados;
    public String tipoQuartoReservado;
    public boolean checkInRealizado;

    public Reserva(Hospede hospede, String dataCheckIn, String dataCheckOut, int numeroQuartosReservados, String tipoQuartoReservado) {
        this.hospede = hospede;
        this.dataCheckIn = dataCheckIn;
        this.dataCheckOut = dataCheckOut;
        this.numeroQuartosReservados = numeroQuartosReservados;
        this.tipoQuartoReservado = tipoQuartoReservado;
        this.checkInRealizado = false;
    }

    public Hospede getHospede() {
        return hospede;
    }

    public String getCheckIn() {
        return dataCheckIn;
    }

    public String getCheckOut() {
        return dataCheckOut;
    }

    public int getNumeroQuartos() {
        return numeroQuartosReservados; 
    }

    public String getTipoQuarto() {
        return tipoQuartoReservado;
    }
    
    public boolean isCheckInRealizado() {
        return checkInRealizado;
    }

    public void setCheckInRealizado(boolean checkInRealizado) {
        this.checkInRealizado = checkInRealizado;
    }
}
