package atv2;

public class Quarto {
    public int numeroQuarto;
    public String tipoQuarto;
    public double precoDiario;
    public boolean disponivel;

    public Quarto(int numeroQuarto, String tipoQuarto, double precoDiario) {
        this.numeroQuarto = numeroQuarto;
        this.tipoQuarto = tipoQuarto;
        this.precoDiario = precoDiario;
        this.disponivel = true;
    }

    public int getNumero() {
        return numeroQuarto;
    }

    public String getTipo() {
        return tipoQuarto;
    }

    public double getPrecoDiario() {
        return precoDiario;
    }

    public boolean isDisponivel() {
        return disponivel;
    }

    public void setDisponivel(boolean disponivel) {
        this.disponivel = disponivel;
    }
}
